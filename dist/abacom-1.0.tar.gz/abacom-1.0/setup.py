from setuptools import setup, find_packages

setup(
    name='abacom',
    version='1.0',
    description='Mi primer software',
    author='Darwin Calle',
    author_email='dacl010811@gmail.com',
    url='https://github.com/',
    packages=find_packages()
)
